This is a texture testing datapack for DelChoco mod.

How to use:
1. Place this folder in your Minecraft resourcepacks folder
2. Place your texture files in the appropriate folders following the same structure as the mod
3. Enable the resource pack in Minecraft to test your textures

Main texture paths:
- assets/delchoco/textures/entities/chocobos/base/ - For chocobo base textures
- assets/delchoco/textures/entities/chicks/ - For chicobo textures
- assets/delchoco/textures/gui/ - For GUI textures
- assets/delchoco/textures/items/ - For item textures

For more information, please refer to the original mod structure.
