Place chicobo textures here, but the proper directory structure should be:
assets/delchoco/textures/entities/chicobos/base/

Valid filenames:
- black.png
- blue.png
- gold.png
- green.png
- pink.png
- purple.png
- red.png
- white.png
- yellow.png
