Place chocobo armor textures here.
Valid Files.
