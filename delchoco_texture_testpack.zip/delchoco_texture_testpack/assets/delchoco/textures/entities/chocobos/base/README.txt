Place chocobo base textures here.
Valid filenames:
- black.png
- blue.png
- gold.png
- green.png
- leather.png
- pink.png
- purple.png
- red.png
- white.png
- yellow.png

