Place chocobo base textures here.
Valid filenames:
- flame.png

