Place chocobo weapon textures here.

Valid filenames:
- chocobo_chain.png
- chocobo_diamond.png
- chocobo_iron.png
- chocobo_netherite.png
