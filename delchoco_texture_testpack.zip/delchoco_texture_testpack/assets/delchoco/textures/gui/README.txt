Place GUI textures here.
do not use without explination on the UI layout.
Valid filenames:
- chocobo_inventory_large.png
- chocobo_inventory_null.png
- chocobo_inventory_small.png
- icons.png
