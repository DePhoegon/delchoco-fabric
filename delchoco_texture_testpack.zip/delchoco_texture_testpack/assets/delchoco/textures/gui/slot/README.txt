Place inventory slot textures here.
Do not use.
Valid filenames:
- empty_armor_slot_boots.png
- empty_armor_slot_chestplate.png
- empty_armor_slot_helmet.png
- empty_armor_slot_leggings.png
- empty_saddle_slot.png
- empty_slot_redstone_dust.png
- empty_weapon_slot.png
