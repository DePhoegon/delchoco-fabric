Place item textures here.
do not use.
Valid filenames:
- chocobo_drumstick_cooked.png
- chocobo_drumstick_raw.png
- chocobo_feather.png
- chocobo_leash_stick.png
- chocobo_whistle.png
- chocopedia.png
- gysahl_green_seeds.png
- pickled_gysahl_cooked.png
- pickled_gysahl_raw.png

Also contains the following subdirectories:
- chocobo_foods/
- choco_gear/
- eggs/
- guise_gear/
